import 'package:assig2/login.dart';
import 'package:assig2/one.dart';
import 'package:flutter/material.dart';

class Create_new extends StatefulWidget {
  const Create_new({Key? key}) : super(key: key);

  @override
  State<Create_new> createState() => _Create_newState();
}

class _Create_newState extends State<Create_new> {
  bool isHide = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body:  Center(
        child: Form(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(30),
                width: 400,
                child: Column(
                  children: [
                    Container(
                      width: 150,
                      height: 150,
                      child: Image.asset("image/create.png"),
                    ),
                    Container(
                      child: Text('Create New Account' ,style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold,color: Colors.black),),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    TextFormField(
                      obscureText: isHide,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0xffE7EDED),
                        hintText: "Email",
                        prefixIcon: Icon(Icons.email),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(40), 
                          borderSide: BorderSide(color: Color(0xffE7EDED)),
                        ),
                        contentPadding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 40.0),
                      ),
                    ),

                    SizedBox(
                      height: 15,
                    ),
                    TextFormField(
                      obscureText: isHide,
                      obscuringCharacter: '*',
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0xffE7EDED),
                        hintText: "Password",
                        prefixIcon: Icon(Icons.lock),
                        suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              isHide = !isHide;
                            });
                          },
                          icon: isHide ? Icon(Icons.visibility) : Icon(Icons.visibility_off),
                        ),
                        // border: InputBorder.none,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(40),
                          borderSide: BorderSide(color: Color(0xffE7EDED)),
                        ),
                        contentPadding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 40.0),
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      width: 350,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        color: Colors.blue
                      ),
                      child: Center(child: Text('Sign up',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.white),),),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      child: Text('or continue with',style: TextStyle(color: Colors.black38,fontWeight: FontWeight.bold),),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 27),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Container(
                              height: 35,
                              width: 40,
                              child: Image.asset('image/f2.png'),
                            ),
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: Container(
                              height: 35,
                              width: 40,
                              child: Image.asset('image/gg.png'),
                            ),
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: Container(
                              height: 35,
                              width: 40,
                              child: Image.asset('image/apple.png'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 26),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              child: Text('Already have an account?',style: TextStyle(color: Colors.grey),),
                            ),
                            SizedBox(width: 6),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => Login()),
                                );
                              },
                              child: Container(
                                child: Text('Sign In',style: TextStyle(color: Colors.blue),),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
