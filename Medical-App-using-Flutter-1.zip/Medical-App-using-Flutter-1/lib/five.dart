import 'package:assig2/six.dart';
import 'package:flutter/material.dart';

class Five extends StatefulWidget {
  const Five({Key? key}) : super(key: key);

  @override
  State<Five> createState() => _FiveState();
}

class _FiveState extends State<Five> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(

        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(bottom: 20),
              child:  Image.asset('image/5.png'),
              width: 320,
            ),
            Container(
              child: Column(
                children: [
                  Center(
                    child: Container(
                      width: 340,
                      height: 200,

                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center, // Center aligning vertically
                        children: [
                          Text(
                            'Lets start living healty and well with us right now!',
                            textAlign: TextAlign.center, // Center aligning text horizontally
                            style: TextStyle(color: Colors.blue, fontSize: 28 ,fontWeight: FontWeight.bold),
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 20),
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [

                                  Container(
                                    width: 5,
                                    height: 5,

                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(100),
                                      color: Colors.grey,
                                    ),
                                  ),
                                  SizedBox(width: 5),
                                  Container(
                                    width: 20,
                                    height: 3,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Container(
                                    width: 5,
                                    height: 5,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(100),
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => Six()),
                              );
                            },
                            child: Container(
                              margin: EdgeInsets.only(top: 15),
                              width: 300,
                              height: 40,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.blue,
                              ),
                              child: Center(
                                child: Text(
                                  'Next',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            )


          ],
        ),
      ),
    );
  }
}
