import 'package:assig2/login.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Startup extends StatefulWidget {
  const Startup({Key? key}) : super(key: key);

  @override
  State<Startup> createState() => _StartupState();
}

class _StartupState extends State<Startup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            Container(
              width: 200,
              // height: 200,
              child: Image.asset('image/start.png'),
            ),
            Container(
              child: Text('Lets you in',style: TextStyle(fontSize: 50,fontWeight: FontWeight.bold,color: Colors.black),),
            ),
            SizedBox(
              height: 35,
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100),
                border: Border.all(color: Color(0xffE7EDED), width: 1),
              ),
              width: 350,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 40,
                    child: Image.asset('image/f2.png'),
                  ),
                  Container(
                    child: Text(
                      'Continue with Facebook',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100),
                border: Border.all(color: Color(0xffE7EDED), width: 1),
              ),
              width: 350,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 40,
                    child: Image.asset('image/gg.png'),
                  ),
                  Container(
                    child: Text(
                      'Continue with Google',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100),
                border: Border.all(color: Color(0xffE7EDED), width: 1),
              ),
              width: 350,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 40,
                    child: Image.asset('image/apple.png'),
                  ),
                  Container(
                    child: Text(
                      'Continue with Apple',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              child: Text('or',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.grey),),
            ),
           GestureDetector(
               onTap: () {
                 Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => Login()),
                 );
               },
             child:  Container(
               margin: EdgeInsets.only(top: 15),
               width: 300,
               height: 40,
               decoration: BoxDecoration(
                 borderRadius: BorderRadius.circular(20),
                 color: Colors.blue,
               ),
               child: Center(
                 child: Text(
                   'Sign in with Password',
                   style: TextStyle(color: Colors.white,fontSize: 12),
                 ),
               ),
             ),
           ),
            Container(
              margin: EdgeInsets.only(top: 26),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      child: Text('Already have an account?',style: TextStyle(color: Colors.grey),),
                    ),
                    SizedBox(width: 6),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Login() ),
                        );
                      },
                      child: Container(
                        child: Text('Sign In',style: TextStyle(color: Colors.blue),),
                      ),
                    )
                  ],
                ),
              ),
            ),


          ],
        ),
      ),
    );
  }
}
