import 'dart:convert';

import 'package:api/ApiServer.dart';
import 'package:api/movie_description.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHome(),
    );
  }
}

class MyHome extends StatefulWidget {
  const MyHome({super.key});

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Working with Api",
            style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.bold,
                color: Colors.white)),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: FutureBuilder(
        future: ApiServer.getApi(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasData) {
            Map map = jsonDecode(snapshot.data);
            List movieData = map["tv_shows"];

            return ListView.builder(
              itemCount: movieData.length,
              physics: const ScrollPhysics(),
              scrollDirection: Axis.vertical,
              itemBuilder: (context, index) {
                int movieID = movieData[index]["id"];
                return GestureDetector(
                  onTap: (){
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("$movieID")));
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Moviesdescription(
                      movieID: movieID,
                    ),));
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(
                          "${movieData[index]["image_thumbnail_path"]}"),
                    ),
                    title: Text("${movieData[index]["name"]}"),
                    subtitle: Text("${movieData[index]["country"]}"),
                  ),
                );
              },
            );
          }

          if (snapshot.hasError) {
            return const Center(
              child: Icon(
                Icons.error,
                color: Colors.red,
              ),
            );
          }

          return Container();
        },
      ),
    );
  }
}
