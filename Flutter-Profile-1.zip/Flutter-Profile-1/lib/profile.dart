import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  List<Map<String, dynamic>> data = [
    {"name": "Fiza", "image": "images/bg.jpeg"},
    {"name": "Iqra", "image": "images/bg.jpeg"},
    {"name": "Laiba", "image": "images/bg.jpeg"},
    {"name": "Abdul Samee Khan", "image": "images/bg.jpeg"},
    {"name": "Faisal", "image": "images/bg.jpeg"},

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
            icon: Icon(Icons.category),
          ),
        ),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              height: 200,
              color: Colors.purple.shade400,
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text("Setting"),
              trailing: Icon(Icons.arrow_forward_outlined),
            ),
            ListTile(
              leading: Icon(Icons.info),
              title: Text("Information"),
              trailing: Icon(Icons.arrow_forward_outlined),
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text("Person"),
              trailing: Icon(Icons.arrow_forward_outlined),
            ),
            ListTile(
              leading: Icon(Icons.privacy_tip),
              title: Text("Privacy"),
              trailing: Icon(Icons.arrow_forward_outlined),
            ),
          ],
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              Container(
                width: double.infinity,
                height: 250,
              ),
              Container(
                width: double.infinity,
                height: 180,
                margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.grey.shade400,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset('images/bg.jpeg', fit: BoxFit.cover,)
                  ],
                ),
              ),
              Positioned(
                left: 30,
                top: 130,
                child: CircleAvatar(
                  backgroundImage: AssetImage('images/bg.jpeg'),
                  radius: 50,
                ),
              ),
              Positioned(
                left: 130,
                top: 190,
                child: Text(
                  "John Doe",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
          Container(
            padding: EdgeInsets.all(6),
            margin: EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade400,
                  blurRadius: 10,
                  spreadRadius: 1,
                )
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Text("89k"),
                    Text(
                      "Followers",
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                  child: VerticalDivider(
                    width: 2,
                    color: Colors.black,
                  ),
                ),
                Column(
                  children: [
                    Text("10k"),
                    Text(
                      "Likes",
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                  child: VerticalDivider(
                    width: 2,
                    color: Colors.black,
                  ),
                ),
                Column(
                  children: [
                    Text("75k"),
                    Text(
                      "Follows",
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                    )
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: Text('Discover people', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                  Container(
                    child: Text('See all', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.blue)),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            height: 210,
            child: ListView.builder(
              itemCount: data.length,
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) { 
                return Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(6)),
                    border: Border.all(width: 1.5, color: Colors.black),
                  ),
                  margin: EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        child: Icon(Icons.close),
                      ),
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.grey.shade400,
                        backgroundImage: AssetImage(data[index]["image"]),
                      ),
                      Container(
                        width: 60,
                        alignment: Alignment.center,
                        child: Text(
                          data[index]["name"],
                          overflow: TextOverflow.ellipsis,style: TextStyle(
                          fontWeight: FontWeight.bold
                        ),
                        ),
                      ),
                      Container(
                        width: 120,
                        alignment: Alignment.center,
                        child: Column(
                          children: [
                            Container(
                              child: Text('Instagram', overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13 ,fontWeight: FontWeight.bold , color: Colors.grey),),
                            ),
                            Container(
                              child: Text('recommended', overflow: TextOverflow.ellipsis , style: TextStyle(fontSize: 13 ,fontWeight: FontWeight.bold , color: Colors.grey)),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            GestureDetector(
                              child: Container(
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(6)),
                                  color: Colors.blue,
                                  border: Border.all(width: 0, color: Colors.transparent),
                                ),
                                width: 120,
                                height: 30,
                                child: Text('Follow', style: TextStyle(color: Colors.white)),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

        ],
      ),
    );
  }
}

