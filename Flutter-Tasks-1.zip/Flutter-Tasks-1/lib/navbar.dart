import 'package:flutter/material.dart';

class navbar extends StatefulWidget {
  const navbar({Key? key}) : super(key: key);

  @override
  State<navbar> createState() => _navbarState();
}

class _navbarState extends State<navbar> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: const Text('faysal'),
              accountEmail: const Text('faysalll@gmail.com'),
              currentAccountPicture: CircleAvatar(
                child: ClipOval(child: Image.asset('images/user.jpg')),
              ),
              decoration: BoxDecoration(
                  color: Colors.pinkAccent,
                  image: DecorationImage(image: AssetImage('images/bg.jpg'),fit: BoxFit.cover)
              ),
            ),
            ListTile(
              leading: const Icon(Icons.file_upload),
              title:  const Text('Upload Shot'),
              onTap: () => print('Upload Shot'),
            ),
            ListTile(
              leading: const Icon(Icons.notifications_active),
              title: const Text('notifications'),
              onTap: () => print('Upload Shot'),
            ),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('share'),
              onTap: () => print('share'),
            ),
            Divider(),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text('Login Out'),
              onTap: () => print('Login Out'),
            ),

          ],
        ),
    );
  }
}
