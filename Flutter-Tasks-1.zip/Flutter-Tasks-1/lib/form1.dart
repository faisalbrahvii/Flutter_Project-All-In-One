import 'package:flutter/material.dart';
// import 'package:achievement_view/achievement_view.dart';
class LoginForm extends StatefulWidget {
  const LoginForm({Key? key});

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  TextEditingController useremail = TextEditingController();
  TextEditingController userpassword = TextEditingController();

  bool isHide = true;
  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        title: Text('Login Form'),
      ),
      body: SingleChildScrollView(

        child: Form(
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              Image.asset("images/user.png"),
              TextFormField(
                controller: useremail,
                decoration: InputDecoration(
                  labelText: "User name",
                  hintText: "Enter Your email",
                  suffixIcon: Icon(Icons.email),
                  icon: Icon(Icons.person),
                ),
              ),
              TextFormField(
                controller: userpassword,
                obscureText: isHide,
                obscuringCharacter: '*',
                decoration: InputDecoration(
                  labelText: "Password",
                  hintText: "Enter Your password",
                  prefixIcon: Icon(Icons.key),
                  suffixIcon: IconButton(onPressed: (){
                    setState(() {
                      isHide = !isHide;
                    });
                  }, icon: isHide == true ? Icon(Icons.visibility_off):Icon(Icons.visibility))

                ),
              ),
              SizedBox(
                height: 20,
              ),

               GestureDetector(
                 onTap: (){
                   // showAchievementView(context);
                   String email = useremail.text;
                   String password = userpassword.text;
                   print(email);
                   print(password);
                 },
                 child: Container(
                   width: 250,
                   height: 50,

                   decoration: BoxDecoration(
                       color: Colors.blue,
                       borderRadius: BorderRadius.circular(12)
                   ),
                   child: Center(child: Text("Login") ),
                 ),
               )

            ],
          ),
        ),
      ),
    );
  }
}

// void showAchievementView(BuildContext context){
//   AchievementView(
//       title: "Yeaaah!",
//       subTitle: "Training completed successfully",
//       //content: Widget()
//       //onTab: _onTabAchievement,
//       icon: Icon(Icons.insert_emoticon, color: Colors.white),
//       //typeAnimationContent: AnimationTypeAchievement.fadeSlideToUp,
//       //borderRadius: 5.0,
//       //color: Colors.blueGrey,
//       //textStyleTitle: TextStyle(),
//       //textStyleSubTitle: TextStyle(),
//       //alignment: Alignment.topCenter,
//       //duration: Duration(seconds: 3),
//       //isCircle: false,
//       listener: (status){
//         print(status);
//         //AchievementState.opening
//         //AchievementState.open
//         //AchievementState.closing
//         //AchievementState.closed
//       }
//   ).show(context);
// }