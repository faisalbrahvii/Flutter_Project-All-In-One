import 'package:flutter/material.dart';

class list_layout extends StatefulWidget {
  const list_layout({Key? key}) : super(key: key);

  @override
  State<list_layout> createState() => _list_layoutState();
}

class _list_layoutState extends State<list_layout> {
  @override
  Widget build(BuildContext context) {
    List my_List = [
      "images/user.png",
      "images/user.png"
    ];
    return Scaffold(
      body: ListView.builder(
        itemCount: my_List.length,
        itemBuilder: (BuildContext context, int index){
          return(
          Column(
            children: [
              Container(
                width: 150,
                height: 150,
                color: Colors.orange,
                child: Image.asset(my_List[index]),
              ),
              SizedBox(
                height: 10,
              ),
            ],
           )
          );
        },
      ),
    );
  }
}
