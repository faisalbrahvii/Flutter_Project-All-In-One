import 'package:flutter/material.dart';
import 'package:sidebar/navbar.dart';
class Sidebar extends StatefulWidget {
  const Sidebar({Key? key}) : super(key: key);

  @override
  State<Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<Sidebar> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
          drawer: navbar(),
          appBar: AppBar(
            title: const  Text('faysal'),
            backgroundColor: Colors.pink,
          ),
          body: SingleChildScrollView(
           child: Column(
             children: [
               Row(
                 children: [
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                 ],
               ),
               SizedBox(
                 height: 10,
               ),
               Row(
                 children: [
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                 ],
               ),
               Row(
                 children: [
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                 ],
               ),
               SizedBox(
                 height: 10,
               ),
               Row(
                 children: [
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                 ],
               ),
               Row(
                 children: [
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                 ],
               ),
               SizedBox(
                 height: 10,
               ),
               Row(
                 children: [
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                   Container(
                     width: 200,
                     height: 200,
                     color: Colors.red,
                   ),
                 ],
               ),

             ],
           ),

          ),
        ),
    );
  }
}
