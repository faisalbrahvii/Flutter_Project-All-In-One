import 'package:flutter/material.dart';
import 'form1.dart';

class Card2 extends StatefulWidget {
  const Card2({Key? key}) : super(key: key);

  @override
  State<Card2> createState() => _Card2State();
}

class _Card2State extends State<Card2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const LoginForm()));
                  },
                  child: Container(
                    width: 200,
                    height: 200,
                    color: Colors.blue,
                    child : Image.asset("images/1.jpg"),
                  ),
                ),

                Container(
                  width: 200,
                  height: 200,
                  color: Colors.green,
                  child : Image.asset("images/2.jpg"),
                ),
              ],
            ),
            SizedBox(
              height:10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 200,
                  height: 200,
                  color: Colors.black,
                  child : Image.asset("images/1.jpg"),
                ),
                Container(
                  width: 200,
                  height: 200,
                  color: Colors.blue,
                  child : Image.asset("images/2.jpg"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
