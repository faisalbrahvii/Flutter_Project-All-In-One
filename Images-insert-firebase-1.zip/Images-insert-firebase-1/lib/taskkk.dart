import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class task extends StatefulWidget {
  const task({Key? key}) : super(key: key);

  @override
  State<task> createState() => _taskState();
}

class _taskState extends State<task> {
  TextEditingController id = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login Page'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 20.0),
            TextField(
              controller: id,
              decoration: InputDecoration(
                labelText: 'student id',
                border: OutlineInputBorder(),
              ),
            ),
            TextField(
              controller: name,
              decoration: InputDecoration(
                labelText: 'student name',
                border: OutlineInputBorder(),
              ),
            ),
            TextField(
              controller: email,
              decoration: InputDecoration(
                labelText: 'student email',
                border: OutlineInputBorder(),
              ),
            ),
            TextField(
              controller: password,
              decoration: InputDecoration(
                labelText: ' student Password',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                String sname = name.text;
                String sid = id.text;
                String semail = email.text;
                String spassword = password.text;

                Map<String, dynamic> studentadd={
                  "student_id":sid,
                "student_name":sname,
                "student_email":semail,
                "student_password":spassword,
                };

                FirebaseFirestore.instance.collection("students").add(studentadd);
                studentadd.clear();
              },
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}
