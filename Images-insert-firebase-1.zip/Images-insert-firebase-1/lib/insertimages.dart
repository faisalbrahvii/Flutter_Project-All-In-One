import 'dart:async';
import 'dart:html';

import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class InsertImage extends StatefulWidget {
  const InsertImage({Key? key}) : super(key: key);

  @override
  State<InsertImage> createState() => _InsertImageState();
}

class _InsertImageState extends State<InsertImage> {
  PlatformFile? pickedFile;

  Future<void> uploadFile() async {

    if (pickedFile == null) {
      return;
    }

    final path = 'Files/${pickedFile!.name}';
    final fileBytes = pickedFile!.bytes!;

    final ref = FirebaseStorage.instance.ref().child(path);
    await ref.putData(fileBytes);

  }

  Future<void> selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null) {
      setState(() {
        pickedFile = result.files.single;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (pickedFile != null)
              Expanded(
                child: Container(
                  color: Colors.blue[100],
                  child: Center(
                    child: Text(pickedFile!.name),
                  ),
                ),
              ),
            ElevatedButton(
              onPressed: selectFile,
              child: const Text('Select File'),
            ),
            ElevatedButton(
              onPressed: uploadFile,
              child: const Text('Upload file'),
            )
          ],
        ),
      ),
    );
  }
}
