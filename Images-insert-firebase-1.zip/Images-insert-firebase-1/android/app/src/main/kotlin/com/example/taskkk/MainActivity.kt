package com.example.taskkk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
