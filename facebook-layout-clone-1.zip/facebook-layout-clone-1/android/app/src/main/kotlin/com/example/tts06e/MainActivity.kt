package com.example.tts06e

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
