package com.example.form2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
