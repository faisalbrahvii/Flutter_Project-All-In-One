import 'package:flutter/material.dart';
import 'package:form2/login.dart';
import 'package:shared_preferences/shared_preferences.dart';
class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {

  String userEmail = "";

  Future getUserDetails() async{
    SharedPreferences userLog = await SharedPreferences.getInstance();
    var email = userLog.getString("userEmail");
    return email;
  }

  void userlogout()async{
    SharedPreferences userLog = await SharedPreferences.getInstance();
    userLog.clear();
    Navigator.push(
        context, MaterialPageRoute(
        builder: (context) => LoginScreen(),

    ));
  }

  @override
  void initState() {
    // TODO: implement initState
    getUserDetails().then(
            (value) {
              setState(() {
                userEmail = value;
              });
            });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(userEmail),
            ElevatedButton(onPressed: (){
              userlogout();
            }, child: Text('Logout')),
          ],

        ),
      ),
    );
  }
}
