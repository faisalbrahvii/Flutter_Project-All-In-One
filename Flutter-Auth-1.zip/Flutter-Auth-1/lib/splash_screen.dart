import 'dart:async';

import 'package:flutter/material.dart';
import 'package:form2/home.dart';
import 'package:form2/login.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  void getDetails()async{
    SharedPreferences userLog = await SharedPreferences.getInstance();
    var email = userLog.getString("userEmail");
    if(email !=null){
      Timer(const Duration(milliseconds: 1000),
              ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=> Home())),
      );
    }else{
      Timer(const Duration(milliseconds: 1000),
            ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginScreen())),
      );
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    getDetails();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
          body: Container(
            child: Text("Splash Screen"),
          ),
    );
  }
}
