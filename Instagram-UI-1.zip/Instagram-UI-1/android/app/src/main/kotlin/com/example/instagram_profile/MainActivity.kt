package com.example.instagram_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
