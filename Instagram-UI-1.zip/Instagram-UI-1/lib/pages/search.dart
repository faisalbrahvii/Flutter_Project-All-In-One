import 'package:flutter/material.dart';
import 'package:instagram_profile/util/explore.dart';

class Search extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: ClipRect(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: Colors.grey[400],
              ),
              padding: EdgeInsets.all(8),
              child: Row(
                children: [
                  Icon(Icons.search, color: Colors.black),
                  Container(
                    child: Text(
                      'search',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      body: Explore(),
      );
  }
}
