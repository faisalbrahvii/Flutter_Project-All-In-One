import 'package:flutter/material.dart';
import 'package:instagram_profile/util/stories.dart';
import 'package:instagram_profile/util/user_post.dart';

class Foryou extends StatefulWidget {
  const Foryou({Key? key}) : super(key: key);

  @override
  State<Foryou> createState() => _ForyouState();
}

class _ForyouState extends State<Foryou> {

 List<Map<String , dynamic>> people = [
   {"name" : "faisal" , "image" : "images/faisal.png"},
   {"name" : "faisal" , "image" : "images/faisal.png"},
   {"name" : "faisal" , "image" : "images/faisal.png"},
 ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Instagram',
              style: TextStyle(color: Colors.black),
            ),
            Row(
              children: [
                Icon(Icons.add),
                Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Icon(Icons.favorite),
                ),
                Icon(Icons.share),
              ],
            )
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            height: 130,
            child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: people.length,
                itemBuilder: (context, index) {
                  return Instagram_Stories(
                      text: people[index]["name"]);
                }
            ),
          ),
          Expanded(
              child: ListView.builder(
                  itemCount: people.length,
                  itemBuilder: (context, index) {
                    return User_post(
                      name: people[index]["name"],
                    );
                  }
              )
          )
        ],
      ),
    );
  }
}

