import 'package:flutter/material.dart';
import 'package:instagram_profile/pages/foryou.dart';
import 'package:instagram_profile/pages/profile.dart';
import 'package:instagram_profile/pages/search.dart';
import 'package:instagram_profile/pages/shop.dart';

class Homepage extends StatefulWidget {
  const Homepage({Key? key}) : super(key: key);

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int _selectIndex = 0;
  void _bottomNav(int index){
      setState(() {
        _selectIndex = index;
      });
  }


  final List<Widget> _children = [
    Foryou(),
    Search(),
    Center(child: Text('Reesls'),),
    Shop(),
    InstagramProfile(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _children[_selectIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectIndex,
        onTap: _bottomNav ,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'search'),
          BottomNavigationBarItem(icon: Icon(Icons.video_call), label: 'reels'),
          BottomNavigationBarItem(icon: Icon(Icons.shop), label: 'shop'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'account'),
        ],
      ),
    );
  }
}
