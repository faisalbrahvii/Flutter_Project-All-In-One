package com.example.imageupload

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
