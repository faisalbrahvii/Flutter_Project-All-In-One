import 'dart:js_interop_unsafe';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

class ProductScreen extends StatefulWidget {
  const ProductScreen({Key? key}) : super(key: key);

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  final TextEditingController pName = TextEditingController();
  final TextEditingController pPrice = TextEditingController();
  List<String> cate = ["Shirts", "Shoes", "Glasses", "Watches"];
  String defaultCate = "Shirts";

  PlatformFile? pickedFile;

  Future<void> uploadFile() async {

    if (pickedFile == null) {
      return;
    }

    final path = 'Files/${pickedFile!.name}';
    final fileBytes = pickedFile!.bytes!;

    final ref = FirebaseStorage.instance.ref().child(path);
    await ref.putData(fileBytes);

  }

  Future<void> selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null) {
      setState(() {
        pickedFile = result.files.single;
      });
    }
  }

  void addProduct() async {
    try {
      await FirebaseFirestore.instance.collection("Product").add({
        "productName": pName.text,
        "productPrice": pPrice.text,
        "productCate": defaultCate
      });
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Product Added")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  void updateProduct(String docID) async {
    try {
      await FirebaseFirestore.instance.collection("Product").doc(docID).update({
        "productName": pName.text,
        "productPrice": pPrice.text,
        "productCate": defaultCate
      });
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Product Updated")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection("Product").snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("Nothing to show"));
          }

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var document = snapshot.data!.docs[index];
              String productName = document["productName"];
              String productPrice = document["productPrice"];
              String productCate = document["productCate"];
              String docID = document.id;

              return ListTile(
                title: Text(productName),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(productPrice),
                    Text(productCate),
                  ],
                ),
                leading: CircleAvatar(backgroundColor: Colors.blue),
                trailing: SizedBox(
                  width: 100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        onPressed: () {
                          showModalBottomSheet(
                            context: context,
                            builder: (context) {
                              pName.text = productName;
                              pPrice.text = productPrice;
                              defaultCate = productCate;

                              return StatefulBuilder(
                                builder: (context, setState) {
                                  return Container(
                                    margin: const EdgeInsets.symmetric(horizontal: 20),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        TextFormField(
                                          controller: pName,
                                          decoration: const InputDecoration(
                                            hintText: "Enter Product Name",
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        TextFormField(
                                          controller: pPrice,
                                          decoration: const InputDecoration(
                                            hintText: "Enter Product Price",
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        DropdownButton(
                                          hint: const Text('Please choose a Category'),
                                          value: defaultCate,
                                          onChanged: (val) {
                                            setState(() {
                                              defaultCate = val.toString();
                                            });
                                          },
                                          items: cate.map((value) {
                                            return DropdownMenuItem(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                        ElevatedButton(
                                          onPressed: () {
                                            updateProduct(docID);
                                          },
                                          child: const Text("Update"),
                                        )
                                      ],
                                    ),
                                  );
                                },
                              );
                            },
                          );
                        },
                        icon: Icon(Icons.edit),
                      ),
                      IconButton(
                        onPressed: () {
                          FirebaseFirestore.instance.collection("Product").doc(docID).delete();
                        },
                        icon: Icon(Icons.delete),
                      )
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showModalBottomSheet(
            context: context,
            builder: (context) {
              return StatefulBuilder(
                builder: (context, setState) {
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                          controller: pName,
                          decoration: const InputDecoration(
                            hintText: "Enter Product Name",
                          ),
                        ),
                        const SizedBox(height: 20),
                        TextFormField(
                          controller: pPrice,
                          decoration: const InputDecoration(
                            hintText: "Enter Product Price",
                          ),
                        ),
                        const SizedBox(height: 20),
                        DropdownButton(
                          hint: const Text('Please choose a Category'),
                          value: defaultCate,
                          onChanged: (val) {
                            setState(() {
                              defaultCate = val.toString();
                            });
                          },
                          items: cate.map((value) {
                            return DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        ElevatedButton(
                          onPressed: selectFile,
                          child: const Text('Select File'),
                        ),
                        // ElevatedButton(
                        //   onPressed: ,
                        //   child: const Text('Upload file'),
                        // ),
                        ElevatedButton(
                          onPressed: () {
                            addProduct();
                            uploadFile();
                          },
                          child: const Text("Add"),
                        )
                      ],
                    ),
                  );
                },
              );
            },
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
